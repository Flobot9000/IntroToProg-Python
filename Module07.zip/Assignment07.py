import pickle  # needed to pickle

# reads text file
def readfile(filename):
    try:  # if the file can't be found/opened
        file = open(filename, "r+")
    except IOError as e:
        print("Error:", e)  # print error to user
    else:  # otherwise do work
        x = file.read().split("\n")  # split on newline to create list
        for y in x:  # for each in list, append to list - removes layered list
            List.append(y)  # append to [list]
        file.close()


# saves variable object to file (pickle)
def exportpickle(newPickle):
    # "wb" will create the file if it doesn't exist
    pic = open(newPickle, "wb")  # write in binary format
    # dump command to export data to file
    pickle.dump(List, pic)  # saves an object [list] to (binary) file
    pic.close()


# imports pickled save file
def importpickle(newPickle):  # loads object from (binary) file
    try:  # if the file can't be found/opened
        pic = open(newPickle, "rb")  # read binary
    except IOError as e:
        print("Error:", e)  # print error to user
    else:  # otherwise do work
        x = pickle.load(pic)
        return x


# initiate list
List = []
# declare files in python project folder
filename = "Elements.txt"
newPickle = "Pickled.txt"
# read text file, which appends as a [list]
readfile(filename)
print("Read:")
# print the [list]
print("------------------")
print("Imported from:", filename)
print(List)
print("------------------")
# pickle and save the object [list]
exportpickle(newPickle)
###
# STOP
###
# import the pickle
print("Load:")
P = importpickle(newPickle)
print("------------------")
print("Imported from:", newPickle)
# print the pickle
print(P)
print("------------------")
