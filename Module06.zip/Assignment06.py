"""
    1)    Make a function for the code that loads each row of data you have from the ToDo.txt text file
            into a Python Dictionary and then adds the rows of data to a Python List.

    2)    Make a function for the code that displays the contents of the Python List object to the user.

    3)    Make a function for the code that allows the user to Add or Remove tasks from the list,
            plus save the tasks in the List tasks-priorities using numbered choices.

    4)    Make a function for the code that saves the data from the table into
            the Todo.txt file when the program exits.

    5)    Make a Class to hold the functions.
"""



# 5. Make a Class to hold the functions
class EditToDo(object):
# Manage a ToDo File of Tasks and Priorities
    def __init__(self):
        self.todo = []

    # 1. Make a function for the code that loads each row of data you have from the ToDo.txt text file
        # into a Python Dictionary and then adds the rows of data to a Python List.
    def ReadFile(self):
        filename = "C:\_PythonClass\Module05\Todo.txt"  # assign disc location of output file
        file = open(filename, "r")  # read file
        self.todo = []
        # read file
        for LN in file:  # loop through file
            T, P = LN.strip().split(',')  # split on comma, assigning each to variables
            dict = {"Task": T.title(), "Priority": P.title()}  # format dictionary w/ earlier variables
            self.todo.append(dict)  # append list w/ new dictionaries (each loop)
        file.close()

    # 2. Make a function for the code that displays the contents of the Python List object to the user.
    def PrintList(self):
        print("\nToDo list, by Task: Priority")
        print("-----------------------------")
        for dict in self.todo:
            # .strip() I  found the same 'space' error between the colon and priority while it was printing to screen
            print(dict['Task'].strip() + ": " + dict['Priority'].strip())
        print("-----------------------------")

    # 3.2 plus save the tasks in the List tasks-priorities using numbered choices.
    def PrintOptions(self):
        print("ToDo Updater: Select from the following options")
        print("-----------------------------")
        print("1. Add a new task")
        print("2. Remove a task")
        print("3. Stop editing and exit")
        print("-----------------------------")

    # 3.1a Make a function for the code that allows the user to Add tasks from the list
    def choice1(self):
        T = input("Enter Task: ")  # get user input, task name
        exists = False  # assign variable to overwrite if true
        # does the task already exist
        for dict in self.todo:  # read dict in list
            if dict['Task'].lower() == T.lower():  # compare user input with dict value
                exists = True  # overwrite variable
        # if not, add it
        if exists == False:
            P = input("Enter Priority (low/med/high): ")  # get user input, priority
            nrow = {"Task": T.title(), "Priority": P.title()}  # Create a dictionary to add to the toDoList list
            self.todo.append(nrow)  # Add the dictionary to the list
            print("List Updated")  # notify user
        else:
            print("\tThat Task already exists!\n")  # notify user

    # 3.1b Make a function for the code that allows the user to Remove tasks from the list
    def choice2(self):
        print("Choose a Task: Priority to remove:")
        print("-----------------------------")
        for count, dict in enumerate(self.todo):
            print(count, "\t", dict['Task'], ":", dict['Priority'])
        print("-----------------------------")
        try:
            R = int(input("What line would you like to remove from ToDo.txt? "))
            self.todo.pop(R)
        except:
            print("\tERROR: Please enter a valid number next time.")

    # 4. Make a function for the code that saves the data from the table into the Todo.txt file when the program exits.
    def choice3(self):
        # save
        save = input("Save to ToDo.txt? (y/n): ")  # get user input, save
        if save == "y":
            filename = "C:\_PythonClass\Module05\Todo.txt"
            file = open(filename, "w")  # we are overwriteing ToDo.txt now that save is confirmed w/ w
            # read dictionary values by key
            for dict in self.todo:
                # .strip() I was having problems with an extra space printing to file
                file.write("%s, %s \n" % (dict['Task'].strip(), dict['Priority'].strip()))
            print("\nToDo.txt Updated with new data entries. \n\tGoodbye")  # notify user data saved
            file.close()
        # exit w/o save
        else:
            print("\tDiscarded changes.\n\tGoodbye")  # notify user no save


# ***PRESENTATION***
x = EditToDo()
x.ReadFile()
x.PrintList()
while True:
    x.PrintOptions()
    try:
        choice = int(input("Choose an option (1,2,3): "))  # get user input choice
        if choice == 1:
            x.PrintList()
            x.choice1()
            x.PrintList()
            continue
        elif choice == 2:
            x.choice2()
            x.PrintList()
            continue
        elif choice == 3:
            x.PrintList()
            x.choice3()
            break
        else:
            print("\tERROR: Please enter a valid number next time.\n\n")  # if a number not in the list is given
    except:
            print("\tERROR: Please enter a valid number next time.\n\n")  # if something besides a number is given


